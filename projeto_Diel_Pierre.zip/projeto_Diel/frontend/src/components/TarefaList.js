
import React, { useState, useEffect } from 'react';

const TarefaList = () => {
  const [tarefas, setTarefas] = useState([]);
  const [filtro, setFiltro] = useState('');

  useEffect(() => {
    async function fetchTarefas() {
      try {
        const response = await fetch('/api/tarefas');
        const data = await response.json();
        setTarefas(data);
      } catch (error) {
        console.error(error);
      }
    }
    fetchTarefas();
  }, []);

  const handleFilterChange = (event) => {
    setFiltro(event.target.value);
  };

  const filteredTarefas = tarefas.filter((tarefa) =>
    tarefa.titulo.toLowerCase().includes(filtro.toLowerCase())
  );

  return (
    <div>
      <h1>Tarefas</h1>
      <input
        type="search"
        value={filtro}
        onChange={handleFilterChange}
        placeholder="Buscar por título"
      />
      <ul>
        {filteredTarefas.map((tarefa) => (
          <li key={tarefa.id}>
            {tarefa.titulo} - {tarefa.data} {tarefa.hora}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TarefaList;