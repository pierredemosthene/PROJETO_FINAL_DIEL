
import React, { useState, useEffect } from 'react';

const TagList = () => {
  const [tags, setTags] = useState([]);
  const [filtro, setFiltro] = useState('');

  useEffect(() => {
    async function fetchTags() {
      try {
        const response = await fetch('/api/tags');
        const data = await response.json();
        setTags(data);
      } catch (error) {
        console.error(error);
      }
    }
    fetchTags();
  }, []);

  const handleFilterChange = (event) => {
    setFiltro(event.target.value);
  };

  const filteredTags = tags.filter((tag) =>
    tag.nome.toLowerCase().includes(filtro.toLowerCase())
  );

  return (
    <div>
      <h1>Tags</h1>
      <input
        type="search"
        value={filtro}
        onChange={handleFilterChange}
        placeholder="Buscar por nome"
      />
      <ul>
        {filteredTags.map((tag) => (
          <li key={tag.id}>{tag.nome}</li>
        ))}
      </ul>
    </div>
  );
};

export default TagList;