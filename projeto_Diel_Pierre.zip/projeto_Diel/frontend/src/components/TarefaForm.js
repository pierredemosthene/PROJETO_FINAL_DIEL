
import React, { useState } from 'react';

const TarefaForm = () => {
  const [titulo, setTitulo] = useState('');
  const [descricao, setDescricao] = useState('');
  const [data, setData] = useState('');
  const [hora, setHora] = useState('');
  const [duracao, setDuracao] = useState('');

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const response = await fetch('/api/tarefas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ titulo, descricao, data, hora, duracao }),
      });
      const data = await response.json();
      console.log(data);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        Título:
        <input type="text" value={titulo} onChange={(event) => setTitulo(event.target.value)} />
      </label>
      <br />
      <label>
        Descrição:
        <textarea value={descricao} onChange={(event) => setDescricao(event.target.value)} />
      </label>
      <br />
      <label>
        Data:
        <input type="date" value={data} onChange={(event) => setData(event.target.value)} />
      </label>
      <br />
      <label>
        Hora:
        <input type="time" value={hora} onChange={(event) => setHora(event.target.value)} />
      </label>
      <br />
      <label>
        Duração:
        <input type="number" value={duracao} onChange={(event) => setDuracao(event.target.value)} />
      </label>
      <br />
      <button type="submit">Salvar</button>
    </form>
  );
};

export default TarefaForm;