const express = require('express');
const app = express();

app.use(express.json());

app.post('/api/tags', (req, res) => {
  const { nome, descricao, data, hora, duracao } = req.body;
  
  res.json({ message: 'Tag foi criado com sucesso!' });
});

app.get('/api/tags', (req, res) => {
  const tags = [
    { id: 1, nome: 'Tag 1', descricao: 'Descrição 1', data: '2023-03-01', hora: '10:00', duracao: 30 },
    { id: 2, nome: 'Tag 2', descricao: 'Descrição 2', data: '2023-03-02', hora: '11:00', duracao: 60 },
    // ...
  ];
  res.json(tags);
});

app.listen(4000, () => {
  console.log('Servidor está rodando na porta 4000');
});