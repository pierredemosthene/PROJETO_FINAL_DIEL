const tagForm = document.getElementById('tagForm');
const tagList = document.getElementById('tagList');

tagForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const nome = document.getElementById('nome').value;
    const descricao = document.getElementById('descricao').value;
    const data = document.getElementById('data').value;
    const hora = document.getElementById('hora').value;
    const duracao = document.getElementById('duracao').value;

    try {
        const response = await fetch('/api/tags', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nome, descricao, data, hora, duracao }),
        });
        const data = await response.json();
        console.log(data);
        renderTag(data);
    } catch (error) {
        console.error(error);
    }
});

async function renderTag(tag) {
    const tagHTML = `
        <div class="tag">
            <h2>${tag.nome}</h2>
            <p>${tag.descricao}</p>
            <p>Data: ${tag.data} - Hora: ${tag.hora} - Duração: ${tag.duracao} minutos</p>
        </div>
    `;
    tagList.innerHTML += tagHTML;
}

async function getTags() {
    try {
        const response = await fetch('/api/tags');
        const data = await response.json();
        data.forEach((tag) => renderTag(tag));
    } catch (error) {
        console.error(error);
    }
}

getTags();