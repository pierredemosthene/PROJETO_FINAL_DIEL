
const express = require('express');
const app = express();
const axios = require('axios');

app.get('/api/feriados', async (req, res) => {
  try {
    const response = await axios.get('https://date.nager.at/api/v2/PublicHolidays/2023/Brazil');
    const feriados = response.data;
    res.send(feriados);
  } catch (error) {
    console.error(error);
    res.status(500).send({ message: 'Erro ao buscar feriados' });
  }
});

module.exports = app;