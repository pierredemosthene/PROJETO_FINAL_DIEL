
const express = require('express');
const app = express();
const mysql = require('mysql');

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'password',
  database: 'diel',
});

app.use(express.json());

app.post('/api/tarefas', (req, res) => {
  const { titulo, descricao, data, hora, duracao } = req.body;
  db.query(
    `INSERT INTO tarefas (titulo, descricao, data, hora, duracao) VALUES (?, ?, ?, ?, ?)`,
    [titulo, descricao, data, hora, duracao],
    (error, results) => {
      if (error) {
        console.error(error);
        res.status(500).send({ message: 'Erro ao salvar tarefa' });
      } else {
        res.send({ message: 'Tarefa salva com sucesso' });
      }
    }
  );
});

app.get('/api/tarefas', (req, res) => {
  db.query('SELECT * FROM tarefas', (error, results) => {
    if (error) {
      console.error(error);
      res.status(500).send({ message: 'Erro ao buscar tarefas' });
    } else {
      res.send(results);
    }
  });
});

module.exports = app;