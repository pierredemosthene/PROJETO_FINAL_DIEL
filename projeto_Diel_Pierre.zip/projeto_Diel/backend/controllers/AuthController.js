
const express = require('express');
const app = express();
const bcrypt = require('bcrypt');

app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const user = await db.query(`SELECT * FROM usuarios WHERE username=?`, username);
    if (!user.length) {
      res.status(401).send({ message: 'Usuário não encontrado' });
    } else {
      const isValidPassword = await bcrypt.compare(password, user[0].password);
      if (!isValidPassword) {
        res.status(401).send({ message: 'Senha inválida' });
      } else {
        res.send({ message: 'Login realizado com sucesso' });
      }
    }
  } catch (error) {
    console.error(error);
    res.status(500).send({ message: 'Erro ao realizar login' });
  }
});

module.exports = app;