module.exports = class Tag {
    constructor(id, nome) {
      this.id = id;
      this.nome = nome;
    }
  };