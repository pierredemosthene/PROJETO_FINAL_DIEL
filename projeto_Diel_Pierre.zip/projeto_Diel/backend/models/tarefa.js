module.exports = class Tarefa {
    constructor(id, titulo, descricao, dataCriacao, dataEntrega, tags) {
      this.id = id;
      this.titulo = titulo;
      this.descricao = descricao;
      this.dataCriacao = dataCriacao;
      this.dataEntrega = dataEntrega;
      this.tags = tags;
    }
  };