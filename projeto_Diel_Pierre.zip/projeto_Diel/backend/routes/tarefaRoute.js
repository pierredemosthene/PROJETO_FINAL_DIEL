const express = require('express');
const router = express.Router();
const TarefaController = require('../controllers/tarefaController');

router.post('/', TarefaController.create);
router.get('/', TarefaController.getAll);
router.get('/:id', TarefaController.getById);
router.put('/:id', TarefaController.update);
router.delete('/:id', Tarendralete);

module.exports = router;