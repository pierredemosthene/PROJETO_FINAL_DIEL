CREATE DATABASE diel;

USE diel;

CREATE TABLE tarefas (
  id INT PRIMARY KEY AUTO_INCREMENT,
  titulo VARCHAR(255),
  descricao TEXT,
  data DATE,
  hora TIME,
  duracao INT
);